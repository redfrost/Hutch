## Hutch

Hutch is a simple and intuitive web-based slideshow framework featuring:

- Auto-fit to user's browser window screen size
- CSS3 animation
- Bootstrap
- Keyboard control
- Touch device

*Some features are not yet included in alpha version.